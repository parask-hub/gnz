import React from "react";
import "./Footer.css";

function Footer() {
  return (
    <div className="footer">
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus
        nam dolore laboriosam minima excepturi velit voluptas dicta adipisci
        eaque reprehenderit.
      </p>
    </div>
  );
}

export default Footer;
