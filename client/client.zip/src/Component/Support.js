import React from "react";

function Support() {
  return (
    <div>
      <div
        className="supportContainer"
        style={{
          height: "86vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <span>
          <img height="200px" src="https://i.gifer.com/XOsX.gif" alt="" />
        </span>{" "}
      </div>
    </div>
  );
}

export default Support;
